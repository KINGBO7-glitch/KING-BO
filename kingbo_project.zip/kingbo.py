from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import requests
from bs4 import BeautifulSoup
from collections import Counter
import uvicorn

app = FastAPI()

TIPMINER_URL = "https://www.tipminer.com/br/historico/jonbet/bac-bo"

def scrape_historico():
    res = requests.get(TIPMINER_URL)
    soup = BeautifulSoup(res.text, "html.parser")
    rodadas = []

    for item in soup.select(".history-list__item"):
        cor = item.get("data-result")
        if cor in ["vermelho", "azul", "empate"]:
            rodadas.append(cor)
    return rodadas

def analisar_probabilidades(rodadas):
    total = len(rodadas)
    contagem = Counter(rodadas)
    prob = {cor: round((contagem.get(cor,0)/total)*100,2) for cor in ["vermelho","azul","empate"]}
    return prob

def detectar_padroes(rodadas):
    padroes = {}
    for i in range(len(rodadas)-2):
        seq = tuple(rodadas[i:i+3])
        padroes[seq] = padroes.get(seq, 0) + 1
    padroes_ordenados = sorted(padroes.items(), key=lambda x: x[1], reverse=True)
    return padroes_ordenados[:5]

@app.get("/", response_class=HTMLResponse)
async def home():
    rodadas = scrape_historico()
    if not rodadas:
        return HTMLResponse("<h1>Erro ao coletar dados do TipMiner.</h1>")
    probabilidades = analisar_probabilidades(rodadas)
    padroes = detectar_padroes(rodadas)

    html = f"""
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <title>KING BO - Análise Bac Bo</title>
        <style>
            body {{
                background: #0d0d0d;
                color: white;
                font-family: 'Arial', sans-serif;
                text-align: center;
                padding: 30px;
            }}
            h1 {{
                font-size: 2.2rem;
                margin-bottom: 20px;
                color: gold;
            }}
            button {{
                padding: 10px 20px;
                font-size: 1.2rem;
                background-color: #222;
                color: white;
                border: 2px solid gold;
                border-radius: 8px;
                cursor: pointer;
            }}
            .rodadas span {{
                margin: 4px;
                font-weight: bold;
                font-size: 1.1rem;
                display: inline-block;
            }}
            .vermelho {{ color: #ff4d4d; }}
            .azul {{ color: #4da6ff; }}
            .empate {{ color: #ccc; }}
            .info-box {{
                background: #1a1a1a;
                padding: 15px;
                border-radius: 10px;
                margin: 20px auto;
                max-width: 500px;
            }}
        </style>
    </head>
    <body>
        <h1>KING BO 👑</h1>
        <button onclick="window.location.reload()">🔄 Analisar Agora</button>

        <div class="info-box">
            <h2>🎯 Últimas Rodadas</h2>
    """
    for r in rodadas[:20]:
        html += f'<span class="{r}">{r[0].upper()}</span> '
    html += "</div>"

    html += f"""
        <div class="info-box">
            <h2>📊 Probabilidades</h2>
            <p class="vermelho">Vermelho: {probabilidades["vermelho"]}%</p>
            <p class="azul">Azul: {probabilidades["azul"]}%</p>
            <p class="empate">Empate: {probabilidades["empate"]}%</p>
        </div>

        <div class="info-box">
            <h2>🔁 Padrões Mais Repetidos</h2>
    """
    for padrao, count in padroes:
        padrao_str = " → ".join(padrao)
        html += f"<p>{padrao_str} - <b>{count}x</b></p>"

    html += """
        </div>
        <footer style="margin-top:40px; font-size: 0.9rem; color: #666;">
            © 2025 KING BO - by Eduardo
        </footer>
    </body>
    </html>
    """
    return HTMLResponse(content=html)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)